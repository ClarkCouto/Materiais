package dao;

import model.Pessoa;

public class PessoaDAO extends BaseDAO <Pessoa>{

    
}