package model;

import dao.PessoaDAO;
import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Pessoa implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pessoa)) {
            return false;
        }
        Pessoa other = (Pessoa) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
    
    public List<Pessoa> buscarTodos() {
        return new PessoaDAO().buscarTodos(Pessoa.class);
    }
    
    public void salvar(){
            new PessoaDAO().salvar(this);
    }
   
    public Integer remover() {
        return new PessoaDAO().remover(Pessoa.class, this.getId());
    }
    
    public Pessoa atualizar() {
        return new PessoaDAO().atualizar(this);
    }
    @Override
    public String toString() {
        return "model.Pessoa[ id=" + id + " ]" + "\nNome: " + nome ;
    }
    
}
