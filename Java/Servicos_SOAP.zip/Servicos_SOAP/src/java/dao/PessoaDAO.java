package dao;

import java.util.*;
import model.Pessoa;

public class PessoaDAO {

    public List<Pessoa> buscarTodos() {
        List<Pessoa> lista = new LinkedList<>();
        lista.add(new Pessoa(123L, "Fulano"));
        lista.add(new Pessoa(456L, "Beltrano"));
        lista.add(new Pessoa(789L, "Beltrana"));
        return lista;
    }
}