package servicos;

import dao.PessoaDAO;
import java.util.List;
import javax.jws.*;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.Endpoint;
import model.Pessoa;

@WebService
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public class ListaPessoas {
    @WebMethod(operationName = "buscarTodos")
     public  List<Pessoa> buscarTodos() {
        return new PessoaDAO().buscarTodos();
    }
     
     public static void main(String[] args) {
         Endpoint.publish("http://localhost:9876/servicos", new ListaPessoas());
         System.out.print("Serviço inicializado");
    }
}
