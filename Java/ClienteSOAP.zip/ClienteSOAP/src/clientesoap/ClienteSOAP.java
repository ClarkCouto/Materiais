/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientesoap;

import java.util.List;
import servicos.*;

public class ClienteSOAP {
    public static void main(String[] args) {
        ListaPessoasService listaFactory = new ListaPessoasService();
        ListaPessoas lista = listaFactory.getListaPessoasPort();
        List<Pessoa> pessoas = lista.buscarTodos();
        for (Pessoa pessoa : pessoas) {
            System.out.println("Pessoa=> "+pessoa.getNome());
        }
    }   
}
